﻿function MegaTest() {
    document.getElementById("testMore").innerHTML = "Mere test";
}

function SortingDishes() {

}